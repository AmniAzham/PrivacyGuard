# Linux desktop installation — 0.1.0 preview

Target: Debian 13 (trixie), x86-64/amd64, glibc 2.41 or newer, with a graphical
session and a local browser. Other distributions and CPU architectures are not
validated. Windows and macOS are unsupported.

The Debian package bundles Python, the application and compiled React interface.
You do not need Python, Node.js, npm or a development checkout. Debian installs the
native libc/libseccomp/zlib dependencies. An existing local browser is required;
this package does not bundle a browser. The interface uses authenticated loopback
HTTP; document workers retain syscall-level network denial and resource limits.

Download `privacyguard_0.1.0-1_debian13_amd64.deb` and `SHA256SUMS` into the same
folder. Check the digest against the independently obtained release checksum:

```sh
sha256sum --check SHA256SUMS
sudo apt install ./privacyguard_0.1.0-1_debian13_amd64.deb
privacyguard
```

Alternatively launch PrivacyGuard from the desktop applications menu. Automatic
opening requires a configured local default browser; if it fails, configure the
browser and retry from a terminal. The advanced `--no-browser` option writes a
private launch ticket for local automation; it never prints authentication URLs.
Do not share the ticket. Keep the application running while reviewing documents.

Scan, review masked findings, approve/reject proposed changes, confirm the review,
then sanitize and verify. Downloads remain **inspect_only**, never certified safe.
Unknown/unsupported content is blocked. Review the downloaded document before
sharing it. No new formats or detection coverage are introduced by this package.

Use Stop local application before closing the browser, or terminate the terminal
process normally. Cancellation waits for worker termination and private cleanup.
Browser downloads are intentional user copies and are not deleted by cleanup.

```sh
sudo apt remove privacyguard
```

Removal deletes installed application files, not browser downloads or user data.
No background service, autostart, telemetry, account or remote processing is added.
The release is unsigned; a checksum detects a mismatch but does not authenticate
its publisher. See RELEASE_NOTES.md for exact validation and remaining limitations.
