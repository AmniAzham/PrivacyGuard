# PrivacyGuard 0.1.0 — first Linux desktop preview

Packaging-only release of the existing local web application. Debian 13 amd64
package with bundled Python runtime and compiled frontend, desktop menu entry and
terminal launcher. No new detectors, file formats or frontend features.

Existing TXT, Markdown, CSV, TSV and restricted DOCX/XLSX/PPTX support is unchanged.
Human review, independent output verification, bounded workers, syscall network
denial, no-overwrite publication and private cleanup remain required. Outputs
remain inspect_only or blocked. This is a preview, not a claim that the broader
product acceptance checklist is complete or that all sensitive data is detectable.

Validation results and artifact checksum are recorded in docs/TEST_STRATEGY.md
and the release's SHA256SUMS. A clean Debian container can establish package
installation/runtime behavior but not graphical desktop integration, browser
association or compatibility with all hardware and distributions. Windows/macOS
remain unsupported. No automatic updater or signed repository is provided.
